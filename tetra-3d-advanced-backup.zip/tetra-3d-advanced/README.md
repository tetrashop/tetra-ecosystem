# 🧠 Tetra 3D Advanced

سیستم پیشرفته پردازش مدل‌های سه‌بعدی با الگوریتم‌های مبتنی بر ریاضیات گسسته

## 🌟 ویژگی‌ها

- **تبدیل هوشمند 2D به 3D** با الگوریتم‌های اختصاصی
- **کاهش پیچیدگی** مبتنی بر کره گسسته
- **پردازش ریاضی** با سیستم‌های پیشامد
- **رابط کاربری فارسی** کاملاً ریسپانسیو

## 🚀 Deployment سریع

### با Vercel:
[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/tetrashop/tetra-3d-advanced)

### یا از طریق CLI:
```bash
npm install -g vercel
vercel --prod
tetra-3d-advanced/
├── index.html          # صفحه اصلی یکپارچه
├── package.json        # پیکربندی پروژه
├── vercel.json         # پیکربندی Vercel
└── README.md          # مستندات
python3 -m http.server 8000
# یا
npm run dev

### 3. تنظیم Git و آپلود به GitHub:

```bash
# پیکربندی Git
git init
git add .
git commit -m "feat: Complete Tetra 3D Advanced system with static deployment

- Single HTML file with all functionality
- Persian RTL interface
- 2D to 3D converter simulation
- Mesh complexity reduction algorithms
- Ready for Vercel deployment
- Responsive design"

# تغییر نام branch به main
git branch -M main

# اضافه کردن remote (با نام کاربری صحیح خودتان)
git remote add origin https://github.com/YOUR_USERNAME/tetra-3d-advanced.git

# Push به GitHub
git push -u origin main
# ایجاد ریپازیتوری جدید در GitHub از طریق مرورگر:
echo "📝 برای ایجاد ریپازیتوری در GitHub:"
echo "1. به https://github.com/new بروید"
echo "2. نام ریپازیتوری را 'tetra-3d-advanced' قرار دهید"
echo "3. تیک 'Initialize with README' را نزنید"
echo "4. روی Create repository کلیک کنید"
echo ""
echo "🎯 سپس دستورات زیر را اجرا کنید:"
echo "git remote add origin https://github.com/YOUR_USERNAME/tetra-3d-advanced.git"
echo "git push -u origin main"
