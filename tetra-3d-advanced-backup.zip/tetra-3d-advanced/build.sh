#!/bin/bash
echo "🔨 Building Tetra 3D Advanced..."
# این یک پروژه استاتیک است، نیازی به build پیچیده نیست
echo "✅ Build completed successfully"
