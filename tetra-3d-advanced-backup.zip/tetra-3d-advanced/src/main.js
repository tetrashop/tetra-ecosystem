import './styles/main.css';

console.log('🚀 Tetra 3D Advanced - Simple Version Loaded');

// تابع ساده برای نمایش کامپوننت‌ها
function initConverter() {
    const container = document.getElementById('converter-app');
    if (container) {
        container.innerHTML = '<div style="text-align: center; padding: 50px; background: #f8f9fa; border-radius: 10px; margin: 20px;">' +
            '<h3>🎨 تبدیل 2D به 3D</h3>' +
            '<p>سیستم تبدیل پیشرفته با الگوریتم‌های ریاضیاتی</p>' +
            '<button class="btn btn-primary" onclick="alert(\\\"تبدیل آغاز شد!\\\")">شروع تبدیل</button>' +
        '</div>';
    }
}

function initReducer() {
    const container = document.getElementById('reducer-app');
    if (container) {
        container.innerHTML = '<div style="text-align: center; padding: 50px; background: #f8f9fa; border-radius: 10px; margin: 20px;">' +
            '<h3>📐 کاهش پیچیدگی مدل</h3>' +
            '<p>الگوریتم مبتنی بر کره گسسته و ریاضیات پیشامد</p>' +
            '<button class="btn btn-secondary" onclick="alert(\\\"الگوریتم اجرا شد!\\\")">اجرای الگوریتم</button>' +
        '</div>';
    }
}

// راه‌اندازی هنگام لود صفحه
document.addEventListener('DOMContentLoaded', function() {
    console.log('🧠 Initializing Tetra 3D Advanced...');
    initConverter();
    initReducer();
    
    // مدیریت نویگیشن
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);
            if (targetSection) {
                targetSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
});
